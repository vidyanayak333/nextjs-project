import { NextApiRequest, NextApiResponse } from "next";
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === "GET") {
    const forums = await prisma.forum.findMany({
      include: { user: true, comments: true },
    });
    return res.status(200).json(forums);
  }

  if (req.method === "POST") {
    const { title, description, tags, userId } = req.body;
    if (!userId) return res.status(400).json({ error: "User ID is required" });

    const newForum = await prisma.forum.create({
      data: { title, description, tags, userId },
    });

    return res.status(201).json(newForum);
  }

  res.setHeader("Allow", ["GET", "POST"]);
  res.status(405).end(`Method ${req.method} Not Allowed`);
}
